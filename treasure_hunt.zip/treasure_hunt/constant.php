<?php
$db_connection= mysqli_connect("localhost","root","","treasure_hunt");
?>