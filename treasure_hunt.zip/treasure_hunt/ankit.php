<?php 
echo rand(1000,10000)*rand(1,1000);
?>