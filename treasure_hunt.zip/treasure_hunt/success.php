<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="css/style.css" />
<title>Untitled Document</title>
</head>
<body>
<div id="main" >
<div id="content" class="clearfix">
<div class="header">Successfully Created Account</div>
<div style="text-align:center">Please Wait for Verification SMS.</div>
<div style="text-align:center">After Receiving Verification Code.. Login To Your Account To Enter Verification Number</div>
</div>
</div>
</body>
</html>